инфо:
    - https://txid.io/wallet/#verify
    - https://bitcoinfees.earn.com/api/v1/fees/recommended
    - https://live.blockcypher.com/btc/decodetx/
    - https://btc.com/tools/tx/decode
    - https://www.bestchange.ru/converter/
    - https://insight.bitpay.com/api/addr/32RSEM62XAmD9AwbkGXRe5M11JwmqZ1fXP/utxo
    - https://github.com/bitcoinjs/bitcoinjs-lib/issues/1176
    - https://medium.com/coinmonks/lets-create-a-secure-hd-bitcoin-wallet-in-electron-react-js-575032c42bf3


формула:
    - https://github.com/mmick66/jswallet/blob/master/src/logic/wallet.class.js#L101


API:
    - баланс https://api.blockcypher.com/v1/btc/test3/addrs/mmJS8KnSoG5fUAMBgtpcdRuddJumPfJVmF/balance
    - транзакции https://api.blockcypher.com/v1/btc/test3/addrs/mmJS8KnSoG5fUAMBgtpcdRuddJumPfJVmF?limit=5


testkey:
    mvvb5Pjixx1Cz6YScuE1wyyxTneWLX42iG / 4b8d9e7c753a0bcf1fd10325a79bc8f07caee215476513cb87776f78e2b52265 / cQ7ZrGk36B72zdkzNMNSoDaGHPirG94Cx6qC8QPGY8Rvuf4uCDri