module.exports = {
    API: require("./API"),
    Wallet: require("./Wallet")
};
