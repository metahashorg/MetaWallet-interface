# Ethereum JS API

## Usage

### Node.js (not published for now)
```javascript
const Ethereum = require('ethereum-client');
```

### Browser
```html
<script src="dist/Ethereum.js"></script>
```

### Create new wallet
```javascript
const Wallet = Ethereum.Wallet;

const wallet = new Wallet();
console.log(wallet.publicKey);
console.log(wallet.privateKey);
console.log(wallet.address);
```

### Restore wallet from private key
```javascript
const Wallet = Ethereum.Wallet;

const wallet = Wallet.fromPrivateKey('0xff5a1607d2193d9bc00a290a1a18e6a22105039ecf660d78b1d38ed7d87254a5');
console.log(wallet.publicKey);
console.log(wallet.privateKey);
console.log(wallet.address);
```

### Restore wallet from V3 JSON
```javascript
const Wallet = Ethereum.Wallet;

const wallet = Wallet.fromV3JSON('{"version":3,"id":"c1179159-5dd7-449e-8d4a-1d4a9f9adb02","address":"580d70d5ff35d6174d1dc4d4b642a00506380045","crypto":{"ciphertext":"f43640388b63b00748e0651580d09ca6ee1a6c67c9191a4e1a2e428d19375160","cipherparams":{"iv":"3a86aedea9dc6a38ddf39dd6b2044cd6"},"cipher":"aes-128-ctr","kdf":"scrypt","kdfparams":{"dklen":32,"salt":"88851f17cca68d5f6f7c1fcf29bc62339f09010aa2526e3eee6a677e07b595cc","n":262144,"r":8,"p":1},"mac":"50a3a4d10fa38487659991cea1995381e03d96608a01071158665ebfd77401f6"}}', 'test2');
console.log(wallet.publicKey);
console.log(wallet.privateKey);
console.log(wallet.address);
```

### Save wallet to V3 JSON
```javascript
const Wallet = Ethereum.Wallet;

const wallet = new Wallet();
const json = wallet.toV3JSON('test2');
console.log(json);
```

## Promise API

### Create and send transaction
```javascript
const Wallet = Ethereum.Wallet;
const API = Ethereum.API;

const wallet = Wallet.fromPrivateKey('0xff5a1607d2193d9bc00a290a1a18e6a22105039ecf660d78b1d38ed7d87254a5');
const api = new API('https://mainnet.infura.io/Ky03pelFIxoZdAUsr82w');

api.getNonce({address: wallet.address}).then((nonce) => {
    const txParams = {
        from: wallet.address,
        to: '0x0000000000000000000000000000000000000000',
        value: 1,
        data: '',
        gasPrice: 1500000000,
        gasLimit: 1000000,
        nonce: nonce
    };

    const tx = wallet.createTx(txParams);
    
    api.sendTx({tx: tx}).then((result) => {
        console.log(result);
    }).catch((error) => {
        console.log(error);
    });
});
```

### Other API methods
```javascript
const Wallet = Ethereum.Wallet;
const API = Ethereum.API;

const wallet = Wallet.fromPrivateKey('0xff5a1607d2193d9bc00a290a1a18e6a22105039ecf660d78b1d38ed7d87254a5');
const api = new API('https://mainnet.infura.io/Ky03pelFIxoZdAUsr82w');

api.fetchBalance({address: wallet.address}).then((result) => {
    console.log(result);
});

api.fetchBalance({address: wallet.address, contract: '0x5ca9a71b1d01849c0a95490cc00559717fcf0d1d'}).then((result) => {
    console.log(result);
});

api.getTx({hash: '0x6a2b263baf6362da4801e464e4093ab845f551d9fb3f2f00f95f308eee116123'}).then((result) => {
    console.log(result);
});
```

## Async/Await API

### Create and send transaction
```javascript
const Wallet = Ethereum.Wallet;
const API = Ethereum.API;

const wallet = Wallet.fromPrivateKey('0xff5a1607d2193d9bc00a290a1a18e6a22105039ecf660d78b1d38ed7d87254a5');
const api = new API('https://mainnet.infura.io/Ky03pelFIxoZdAUsr82w');

const nonce = await api.getNonce({address: wallet.address});
const txParams = {
    from: wallet.address,
    to: '0x0000000000000000000000000000000000000000',
    value: 1,
    data: '',
    gasPrice: 1500000000,
    gasLimit: 1000000,
    nonce: nonce
};
    
const tx = wallet.createTx(txParams);
    
const result = await api.sendTx({tx: tx});
console.log(result);

const erc20TxParams = {
    contract: '0x5ca9a71b1d01849c0a95490cc00559717fcf0d1d',
    from: wallet.address,
    to: '0x0000000000000000000000000000000000000000',
    value: 1,
    gasPrice: 1500000000,
    gasLimit: 1000000,
    nonce: nonce
};

const erc20Tx = wallet.createERC20TransferTx(erc20TxParams);
```

### Other API methods
```javascript
const Wallet = Ethereum.Wallet;
const API = Ethereum.API;

const wallet = Wallet.fromPrivateKey('0xff5a1607d2193d9bc00a290a1a18e6a22105039ecf660d78b1d38ed7d87254a5');
const api = new API('https://mainnet.infura.io/Ky03pelFIxoZdAUsr82w');

const balanceResult = await api.fetchBalance({address: wallet.address});
console.log(balanceResult);

const contractBalanceResult = await api.fetchBalance({address: wallet.address, contract: '0x5ca9a71b1d01849c0a95490cc00559717fcf0d1d'});
console.log(contractBalanceResult);

const txResult = await api.getTx({hash: '0x6a2b263baf6362da4801e464e4093ab845f551d9fb3f2f00f95f308eee116123'});
console.log(txResult);
```
